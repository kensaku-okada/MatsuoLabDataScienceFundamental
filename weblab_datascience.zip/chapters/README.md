GCI
=======

# 受講を始める前に

本講座ではjupyter notebookを使うので、事前に環境のセットアップをしてください。
Anaconda( https://www.anaconda.com/ )やiLect( http://ilect.net/ )の使用をおすすめします。なお、Anacondaをご使用の場合、ご自身でデータベースをセットアップする必要があります。
